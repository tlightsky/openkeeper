#!/bin/bash

sudo /usr/sbin/pppoe-stop
